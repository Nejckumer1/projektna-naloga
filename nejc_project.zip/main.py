import router
import bottle

bottle.run(debug=True, reloader=True)